/* Optional: paste your FREE Supabase project URL + anon (publishable) key to turn on
   cross-device accounts, leaderboard and online play. Leave empty for local-only mode.
   NEVER put a service-role key here. NEVER put any password in this file.
   LOCAL_MEGA_USERNAME only matters in local mode (no Supabase). Online, mega admin is set by the database. */
window.PC_CONFIG={SUPABASE_URL:"",SUPABASE_ANON_KEY:"",LOCAL_MEGA_USERNAME:"Landon2"};
